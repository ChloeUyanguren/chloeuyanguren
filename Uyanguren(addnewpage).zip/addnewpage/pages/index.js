import Login from '@/pages/login';

export default function Home() {

  return (
    <div>
      <Login/>
    </div>
  )
}